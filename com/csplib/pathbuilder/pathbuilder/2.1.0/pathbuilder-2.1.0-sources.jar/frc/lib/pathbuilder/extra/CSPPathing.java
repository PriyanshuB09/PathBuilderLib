package frc.lib.pathbuilder.extra;

import static edu.wpi.first.units.Units.MetersPerSecond;

import com.pathplanner.lib.path.PathPlannerPath;
import edu.wpi.first.math.controller.ProfiledPIDController;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.Subsystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Path building helper that uses CSPPilot.
 */
public class CSPPathing {
  private static Subsystem drive;

  private final CSPPilot pilot;
  private final ProfiledPIDController headingController;
  private final List<PathPlannerPath> paths = new ArrayList<>();

  private Pose2d startPose = null;

  private Supplier<Pose2d> getPose;
  private Consumer<Pose2d> setPose;
  private Supplier<ChassisSpeeds> getChassisSpeeds;
  private Consumer<ChassisSpeeds> runVelocity;
  private Runnable stopDrive;

  public CSPPathing(Subsystem drive, CSPPilot pilot, ProfiledPIDController headingController) {
    CSPPathing.drive = drive;
    this.pilot = pilot;
    this.headingController = headingController;
  }

  public CSPPathing withMethods(Supplier<Pose2d> sp, Consumer<Pose2d> cp, Supplier<ChassisSpeeds> sc, Consumer<ChassisSpeeds> cc) {
    getPose = sp;
    setPose = cp;
    getChassisSpeeds = sc;
    runVelocity = cc;
    return this;
  }

  public CSPPathing withStartPose(Pose2d pose) {
    this.startPose = pose;
    return this;
  }

  public CSPPathing addPath(PathPlannerPath path) {
    paths.add(path);
    return this;
  }

  public CSPPathing addPaths(PathPlannerPath... morePaths) {
    for (PathPlannerPath path : morePaths) {
      addPath(path);
    }
    return this;
  }

  public Command build() {
    if (paths.isEmpty()) {
      throw new IllegalStateException("No paths defined");
    }

    final int lastIndex = paths.size() - 1;
    final int[] index = new int[] {0};
    final CSPPilot.PathFollower[] followers = new CSPPilot.PathFollower[paths.size()];

    return Commands.run(
            () -> {
              Pose2d pose = getPose.get();
              ChassisSpeeds robotSpeeds = getChassisSpeeds.get();

              while (index[0] < lastIndex
                  && followers[index[0]] != null
                  && followers[index[0]].isFinished(pose)) {
                index[0]++;
              }

              CSPPilot.PathFollower follower = followers[index[0]];
              CSPPilot.CSPResult out = follower.update(pose, robotSpeeds);

              double omega =
                  headingController.calculate(
                      pose.getRotation().getRadians(), out.targetAngle().getRadians());

              ChassisSpeeds speeds =
                  ChassisSpeeds.fromFieldRelativeSpeeds(
                      out.vx().in(MetersPerSecond),
                      out.vy().in(MetersPerSecond),
                      omega,
                      pose.getRotation());

              runVelocity.accept(speeds);
            },
            drive)
        .beforeStarting(
            () -> {
              index[0] = 0;

              Pose2d reset = startPose != null ? startPose : getPose.get();
              if (startPose != null) {
                setPose.accept(startPose);
              }
              headingController.reset(reset.getRotation().getRadians());

              for (int i = 0; i < paths.size(); i++) {
                followers[i] = pilot.followPath(paths.get(i));
                followers[i].reset();
              }
            })
        .until(() -> followers[lastIndex] != null && followers[lastIndex].isFinished(getPose.get()))
        .finallyDo(interrupted -> Commands.runOnce(stopDrive));
  }
}