package frc.lib.pathbuilder.extra;

import static edu.wpi.first.units.Units.Centimeters;
import static edu.wpi.first.units.Units.Degrees;
import static edu.wpi.first.units.Units.MetersPerSecond;

import com.therekrab.autopilot.*;
import com.therekrab.autopilot.Autopilot.APResult;
import edu.wpi.first.math.controller.ProfiledPIDController;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.Subsystem;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public final class PosePathing {

  private static double maxVel;
  private static double maxAcc;
  private static Supplier<Pose2d> getPose;
  private static Consumer<Pose2d> setPose;
  private static Supplier<ChassisSpeeds> getChassisSpeeds;
  private static Consumer<ChassisSpeeds> runVelocity;
  private static Subsystem drive;
  private static Runnable stopDrive;

  private static final APConstraints baseConstraints =
      new APConstraints()
          .withAcceleration(maxAcc)
          .withJerk(2.0)
          .withVelocity(maxVel);

  private static final APProfile baseProfile =
      new APProfile(baseConstraints)
          .withErrorXY(Centimeters.of(2))
          .withErrorTheta(Degrees.of(0.5))
          .withBeelineRadius(Centimeters.of(5));

  private static final Autopilot baseAutopilot = new Autopilot(baseProfile);
  private final ProfiledPIDController headingController;
  private final List<Waypoint> waypoints = new ArrayList<>();

  private double handoffThresholdMeters = 0.25;
  private Pose2d startPose = null;

  // =========================
  // WAYPOINT (NOW HAS SPEED)
  // =========================
  private static final class Waypoint {
    final Pose2d pose;
    final APTarget target;
    final APConstraints constraints; // NEW

    Waypoint(Pose2d pose, APTarget target, APConstraints constraints) {
      this.pose = pose;
      this.target = target;
      this.constraints = constraints;
    }
  }

  public PosePathing(Subsystem drive, Supplier<Pose2d> getPose, Consumer<Pose2d> setPose, Supplier<ChassisSpeeds> getChassisSpeeds, Consumer<ChassisSpeeds> runVelocity, Runnable stopDrive, ProfiledPIDController headingController, double maxVel, double maxAcc) {
    PosePathing.maxVel = maxVel;
    PosePathing.maxAcc = maxAcc;
    PosePathing.getPose = getPose;
    PosePathing.setPose = setPose;
    PosePathing.getChassisSpeeds = getChassisSpeeds;
    PosePathing.runVelocity = runVelocity;
    PosePathing.drive = drive;
    PosePathing.stopDrive = stopDrive;
    
    this.headingController = headingController;
  }

  public PosePathing withStartPose(Pose2d pose) {
    this.startPose = pose;
    return this;
  }

  public PosePathing withHandoffThreshold(double meters) {
    this.handoffThresholdMeters = meters;
    return this;
  }

  public PosePathing addWaypoint(Pose2d pose) {
    return addWaypoint(pose, t -> t, null);
  }

  public PosePathing addWaypoint(Pose2d pose, Function<APTarget, APTarget> config) {
    return addWaypoint(pose, config, null);
  }

  public PosePathing addWaypoint(
      Pose2d pose, Function<APTarget, APTarget> config, APConstraints speedConstraints) {

    APTarget target = config.apply(new APTarget(pose));

    waypoints.add(new Waypoint(pose, target, speedConstraints));
    return this;
  }

  // convenience overload
  public PosePathing addWaypoint(Pose2d pose, APTarget target, APConstraints speedConstraints) {

    waypoints.add(new Waypoint(pose, target, speedConstraints));
    return this;
  }

  public Command build() {

    if (waypoints.isEmpty()) {
      throw new IllegalStateException("No waypoints defined");
    }

    final int lastIndex = waypoints.size() - 1;
    final AtomicInteger index = new AtomicInteger(0);

    Command main =
        Commands.run(
                () -> {
                  Pose2d pose = getPose.get();
                  ChassisSpeeds robotSpeeds = getChassisSpeeds.get();

                  // ===== Handoff logic =====
                  while (index.get() < lastIndex
                      && distance(pose, waypoints.get(index.get()).pose)
                          <= handoffThresholdMeters) {

                    index.incrementAndGet();
                    // headingController.reset(pose.getRotation().getRadians());
                  }

                  Waypoint wp = waypoints.get(index.get());

                  // =========================
                  // PER-WAYPOINT AUTOPILOT
                  // =========================
                  Autopilot autopilot =
                      (wp.constraints != null)
                          ? new Autopilot(
                              new APProfile(wp.constraints)
                                  .withErrorXY(Centimeters.of(2))
                                  .withErrorTheta(Degrees.of(0.5))
                                  .withBeelineRadius(Centimeters.of(20)))
                          : baseAutopilot;

                  APResult out = autopilot.calculate(pose, robotSpeeds, wp.target);

                  double omega =
                      headingController.calculate(
                          pose.getRotation().getRadians(), out.targetAngle().getRadians());

                  ChassisSpeeds speeds =
                      ChassisSpeeds.fromFieldRelativeSpeeds(
                          out.vx().in(MetersPerSecond),
                          out.vy().in(MetersPerSecond),
                          omega,
                          pose.getRotation());

                  runVelocity.accept(speeds);
                },
                drive)
            .beforeStarting(
                () -> {
                  index.set(0);
                  Pose2d reset = startPose != null ? startPose : getPose.get();
                  headingController.reset(reset.getRotation().getRadians());
                  if (startPose != null) setPose.accept(startPose);
                })
            .until(
                () ->
                    index.get() == lastIndex
                        && baseAutopilot.atTarget(getPose.get(), waypoints.get(lastIndex).target))
            .finallyDo(interrupted -> Commands.runOnce(stopDrive));

    return main;
  }

  private static double distance(Pose2d a, Pose2d b) {
    return a.getTranslation().getDistance(b.getTranslation());
  }
}
